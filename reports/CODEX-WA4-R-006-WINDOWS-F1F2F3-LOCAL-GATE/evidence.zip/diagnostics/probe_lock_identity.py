import sys,tempfile,unittest
from pathlib import Path
sys.path.insert(0,r"M:\GitHub\ag_llm")
from web_alarm.closeout import CloseoutService,CloseoutError
class LockIdentity(unittest.TestCase):
 def test_invalid_identity_does_not_create_outside_operations_lock(self):
  with tempfile.TemporaryDirectory(prefix="wa4r006_badid_") as directory:
   root=Path(directory)/"state"; service=CloseoutService(root)
   with self.assertRaises(CloseoutError): service.complete("../outside")
   self.facts=[{"outside_lock_exists":(root/"locks/outside.lock").exists(),"locks":[p.relative_to(root).as_posix() for p in (root/"locks").rglob("*")]}]
   self.assertFalse((root/"locks/outside.lock").exists(),"invalid closeout task_id escaped operations lock directory before validation")
if __name__=="__main__":
 from wa4a_acceptance import run_tests
 raise SystemExit(run_tests(["__main__.LockIdentity"],sys.argv[1],task_id="CODEX-WA4-R-006-WINDOWS-F1F2F3-LOCAL-GATE"))
